import pygame
import random
import sys
import asyncio

pygame.init()

# === Responsive Screen Scaling ===
DEFAULT_WIDTH, DEFAULT_HEIGHT = 420, 680
screen = pygame.display.set_mode((DEFAULT_WIDTH, DEFAULT_HEIGHT), pygame.RESIZABLE)
pygame.display.set_caption("HUD HUD DABANG DABANG!!!")
clock = pygame.time.Clock()

def get_scale():
    w, h = screen.get_size()
    return min(w / DEFAULT_WIDTH, h / DEFAULT_HEIGHT)

def get_dimensions():
    w, h = screen.get_size()
    scale = get_scale()
    return w, h, scale

# === Colors ===
BG = (18, 18, 24)
WHITE = (245, 245, 245)
RED = (255, 0, 0)
PHYS = (120, 220, 120)
CHEM = (255, 102, 255)
MATH = (90, 150, 255)
PIPE_COLORS = {"Physics": PHYS, "Chemistry": CHEM, "Mathematics": MATH}

# === Fonts ===
def get_fonts(scale):
    # Cache fonts per scale to avoid reloading every frame
    font_sizes = (int(52 * scale), int(36 * scale), int(28 * scale))
    return tuple(pygame.font.Font(None, size) for size in font_sizes)

# === Bird ===
bird_cache = {}
def make_bird_surface(scale):
    """Load & cache bird surface per scale to avoid re-scaling every frame."""
    key = round(scale, 2)
    if key in bird_cache:
        return bird_cache[key]
    try:
        surf = pygame.image.load("bird.png").convert_alpha()
        surf = pygame.transform.smoothscale(surf, (int(44 * scale), int(34 * scale)))
    except:
        surf = pygame.Surface((int(44 * scale), int(34 * scale)), pygame.SRCALPHA)
        pygame.draw.ellipse(surf, (255, 190, 200), (0, int(2*scale), int(44*scale), int(30*scale)))
        pygame.draw.circle(surf, (255, 120, 140), (int(32*scale), int(16*scale)), int(6*scale))
        pygame.draw.circle(surf, (0, 0, 0), (int(18*scale), int(14*scale)), int(3*scale))
    bird_cache[key] = surf
    return surf

def reset_bird(scale, height):
    surf = make_bird_surface(scale)
    rect = surf.get_rect(center=(int(90 * scale), height // 2))
    return surf, rect

# === Physics ===
def get_physics(scale):
    return 0.55 * scale, -9.5 * scale

# === Pipes ===
def get_pipe_params(scale, height):
    return int(70 * scale), int(170 * scale), 4.2 * scale

SPAWN_MS = 1200
SPAWNPIPE = pygame.USEREVENT + 1
pygame.time.set_timer(SPAWNPIPE, SPAWN_MS)

subjects = ["Physics", "Chemistry", "Mathematics"]
pipes = []

def create_pipe_pair(scale, width, height, PIPE_WIDTH, GAP):
    subject = random.choice(subjects)
    center_y = random.randint(int(170 * scale), height - int(170 * scale))
    top_rect = pygame.Rect(width + 40, 0, PIPE_WIDTH, center_y - GAP // 2)
    bottom_rect = pygame.Rect(width + 40, center_y + GAP // 2, PIPE_WIDTH, height - (center_y + GAP // 2))
    return {"top": top_rect, "bottom": bottom_rect, "subject": subject, "counted": False}

def move_pipes(pipes_list, PIPE_SPEED, dt):
    speed = PIPE_SPEED * dt
    for p in pipes_list:
        p["top"].x -= speed
        p["bottom"].x -= speed
    return [p for p in pipes_list if p["top"].right > -5]

def draw_pipes(pipes_list, label_font, scale):
    for p in pipes_list:
        color = PIPE_COLORS[p["subject"]]
        pygame.draw.rect(screen, color, p["top"])
        pygame.draw.rect(screen, color, p["bottom"])
        label = label_font.render(p["subject"], True, (20, 20, 20))
        label_r = pygame.transform.rotate(label, 90)
        lx = p["top"].centerx - label_r.get_width() // 2
        ly_top = p["top"].bottom - min(int(120*scale), p["top"].height // 2)
        ly_bot = p["bottom"].top + int(20*scale)
        screen.blit(label_r, (lx, ly_top - label_r.get_height() // 2))
        screen.blit(label_r, (lx, ly_bot))

# === Collision Cause ===
collision_cause = None
cause_images = {}

from pathlib import Path
import re

collision_cause = None
cause_images = {}

def load_cause_images(scale):
    global cause_images, CAUSE_IMAGE_SIZE

    CAUSE_IMAGE_SIZE = 300
    key = round(scale, 2)

    if key in cause_images:
        return cause_images[key]

    images = {}
    extensions = {".png", ".jpg", ".jpeg", ".webp"}

    for name in ["physics", "mathematics", "chemistry", "boundary"]:
        variants = []

        if name == "boundary":
            filenames = [Path("boundary.jpg")]
        else:
            # Find files like physics1.png, physics2.jpg, etc.
            filenames = sorted(
                (
                    path for path in Path(".").iterdir()
                    if path.is_file()
                    and path.suffix.lower() in extensions
                    and re.fullmatch(
                        rf"{re.escape(name)}\d+",
                        path.stem,
                        re.IGNORECASE
                    )
                ),
                key=lambda path: int(re.search(r"\d+", path.stem).group())
            )

        for filename in filenames:
            try:
                img = pygame.image.load(str(filename)).convert_alpha()
                img = pygame.transform.smoothscale(
                    img,
                    (
                        max(1, int(CAUSE_IMAGE_SIZE * scale)),
                        max(1, int(CAUSE_IMAGE_SIZE * scale))
                    )
                )
            except (pygame.error, OSError):
                continue

            variants.append(img)

        if not variants:
            # Fallback if no valid images are found
            size = max(1, int(180 * scale))
            img = pygame.Surface((size, size), pygame.SRCALPHA)
            pygame.draw.circle(
                img, (200, 50, 50),
                (size // 2, size // 2),
                size // 2
            )
            variants.append(img)

        images[name] = variants

    cause_images[key] = images
    return images



def check_collision(bird_rect, pipes_list, height):
    if bird_rect.top <= 0 or bird_rect.bottom >= height:
        return "boundary"
    for p in pipes_list:
        if bird_rect.colliderect(p["top"]) or bird_rect.colliderect(p["bottom"]):
            return p["subject"].lower()  # physics, maths, chemistry
    return None


def rotated_bird(surf, angle):
    return pygame.transform.rotate(surf, angle)

# === Game State ===
score, best = 0, 0
game_active, show_help = True, True

def reset_game():
    global pipes, bird_surface, bird_rect, bird_vel, rotation, score, game_active, show_help, collision_cause, chosen_image
    width, height, scale = get_dimensions()
    bird_surface, bird_rect = reset_bird(scale, height)
    pipes.clear()
    bird_vel, rotation, score = 0.0, 0.0, 0
    game_active, show_help = True, True
    collision_cause, chosen_image = None, None  # reset cause & image


reset_game()

# === Main Game Loop ===
async def main():
    
    global pipes, bird_surface, bird_rect, bird_vel, rotation, score, best, game_active, show_help, screen, title_font, ui_font, label_font, last_scale, collision_cause, chosen_image, cause_images, VARIANT_COUNT, collision_cause, chosen_image
    
    last_scale = None
    collision_cause = None
    chosen_image = None  # will hold the specific variant chosen
    cause_images = {}
    VARIANT_COUNT = 3  # how many numbered images per subject
    collision_cause = None
    chosen_image = None

    

    while True:
        width, height, scale = get_dimensions()
        if last_scale != scale:  # Only reload fonts if scale changes
            title_font, ui_font, label_font = get_fonts(scale)
            last_scale = scale
        gravity, jump_strength = get_physics(scale)
        PIPE_WIDTH, GAP, PIPE_SPEED = get_pipe_params(scale, height)

        dt = clock.tick(60) / (1000 / 60.0)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            if event.type in (pygame.KEYDOWN, pygame.FINGERDOWN):
                if (event.type == pygame.KEYDOWN and event.key in (pygame.K_SPACE, pygame.K_UP)) or event.type == pygame.FINGERDOWN:
                    if not game_active:
                        reset_game()
                    bird_vel, rotation, show_help = jump_strength, 20, False
            if event.type == SPAWNPIPE and game_active:
                pipes.append(create_pipe_pair(scale, width, height, PIPE_WIDTH, GAP))
            if event.type == pygame.VIDEORESIZE:
                screen = pygame.display.set_mode((event.w, event.h), pygame.RESIZABLE)
                reset_game()

        if game_active:
            bird_vel += gravity
            bird_rect.centery += int(bird_vel)
            rotation = max(-60, rotation - 4)
            pipes = move_pipes(pipes, PIPE_SPEED, dt)
            for p in pipes:
                if not p["counted"] and p["top"].right < bird_rect.left:
                    p["counted"], score = True, score + 1

            cause = check_collision(bird_rect, pipes, height)
            if cause:
                collision_cause = cause
                images = load_cause_images(scale)
                chosen_image = random.choice(images[collision_cause])  # pick one fresh every game
                game_active, best = False, max(best, score)



        # === Drawing ===
        screen.fill(BG)

        # Light grid (pre-calculated step)
        grid_step = int(35 * scale)
        for x in range(0, width, grid_step):
            pygame.draw.line(screen, (24, 24, 32), (x, 0), (x, height))
        for y in range(0, height, grid_step):
            pygame.draw.line(screen, (24, 24, 32), (0, y), (width, y))

        draw_pipes(pipes, label_font, scale)
        screen.blit(rotated_bird(bird_surface, rotation), bird_rect)

        # UI
        title = title_font.render("XII C", True, WHITE)
        screen.blit(title, (width//2 - title.get_width()//2, int(24*scale)))
        s_text = ui_font.render(f"Subjects survived: {score}", True, WHITE)
        b_text = ui_font.render(f"Best: {best}", True, WHITE)
        screen.blit(s_text, (int(16*scale), int(70*scale)))
        screen.blit(b_text, (width - b_text.get_width() - int(16*scale), int(70*scale)))

        if show_help and game_active:
            help_msg = ui_font.render("Press SPACE or Tap to flap", True, WHITE)
            screen.blit(help_msg, (width//2 - help_msg.get_width()//2, height//2 - int(16*scale)))

        if not game_active:
            # Draw chosen random image
            if chosen_image:
                rect = chosen_image.get_rect(center=(width//2, height//2))
                screen.blit(chosen_image, rect)

            # Blinking Game Over text
            blink = (pygame.time.get_ticks() // 500) % 2
            if blink:
                over = title_font.render("Game Over", True, RED) # type: ignore
                screen.blit(over, (width//2 - over.get_width()//2, height//2 - over.get_height()//2))

            # Retry tip
            tip = ui_font.render("Press SPACE or Tap to try again", True, WHITE) # type: ignore
            screen.blit(tip, (width//2 - tip.get_width()//2, height//2 + int(120*scale)))


        pygame.display.flip()
        await asyncio.sleep(0)

asyncio.run(main())
