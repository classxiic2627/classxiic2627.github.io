import asyncio
import random
from pathlib import Path

import pygame


# ============================================================
# INITIALIZATION
# ============================================================

pygame.init()

DEFAULT_WIDTH = 420
DEFAULT_HEIGHT = 680

screen = pygame.display.set_mode(
    (DEFAULT_WIDTH, DEFAULT_HEIGHT),
    pygame.RESIZABLE
)

pygame.display.set_caption("HUD HUD DABANG DABANG!!!")

clock = pygame.time.Clock()


# ============================================================
# CONSTANTS
# ============================================================

BG = (18, 18, 24)
GRID = (24, 24, 32)
WHITE = (245, 245, 245)
RED = (255, 0, 0)

PHYS = (120, 220, 120)
CHEM = (255, 102, 255)
MATH = (90, 150, 255)

PIPE_COLORS = {
    "Physics": PHYS,
    "Chemistry": CHEM,
    "Mathematics": MATH,
}

SUBJECTS = [
    "Physics",
    "Chemistry",
    "Mathematics",
]

SPAWN_MS = 1200
SPAWNPIPE = pygame.USEREVENT + 1

pygame.time.set_timer(SPAWNPIPE, SPAWN_MS)


# ============================================================
# RESPONSIVE SCALING
# ============================================================

def get_scale():
    width, height = screen.get_size()
    return min(
        width / DEFAULT_WIDTH,
        height / DEFAULT_HEIGHT
    )


def get_dimensions():
    width, height = screen.get_size()
    scale = get_scale()
    return width, height, scale


# ============================================================
# FONTS
# ============================================================

font_cache = {}


def get_fonts(scale):
    key = round(scale, 2)

    if key not in font_cache:
        sizes = (
            max(1, int(52 * scale)),
            max(1, int(36 * scale)),
            max(1, int(28 * scale)),
        )

        font_cache[key] = (
            pygame.font.Font(None, sizes[0]),
            pygame.font.Font(None, sizes[1]),
            pygame.font.Font(None, sizes[2]),
        )

    return font_cache[key]


# ============================================================
# BIRD
# ============================================================

bird_cache = {}


def make_bird_surface(scale):
    key = round(scale, 2)

    if key in bird_cache:
        return bird_cache[key]

    width = max(1, int(44 * scale))
    height = max(1, int(34 * scale))

    try:
        bird = pygame.image.load("bird.png").convert_alpha()

        bird = pygame.transform.smoothscale(
            bird,
            (width, height)
        )

    except (pygame.error, OSError):
        bird = pygame.Surface(
            (width, height),
            pygame.SRCALPHA
        )

        pygame.draw.ellipse(
            bird,
            (255, 190, 200),
            (
                0,
                int(2 * scale),
                width,
                max(1, int(30 * scale)),
            )
        )

        pygame.draw.circle(
            bird,
            (255, 120, 140),
            (
                int(32 * scale),
                int(16 * scale)
            ),
            max(1, int(6 * scale))
        )

        pygame.draw.circle(
            bird,
            (0, 0, 0),
            (
                int(18 * scale),
                int(14 * scale)
            ),
            max(1, int(3 * scale))
        )

    bird_cache[key] = bird

    return bird


def reset_bird(scale, height):
    surface = make_bird_surface(scale)

    rect = surface.get_rect(
        center=(
            int(90 * scale),
            height // 2
        )
    )

    return surface, rect


# ============================================================
# PHYSICS
# ============================================================

def get_physics():
    gravity = 0.55
    jump_strength = -9.5

    return gravity, jump_strength


# ============================================================
# PIPES
# ============================================================

def get_pipe_params(scale):
    pipe_width = max(1, int(70 * scale))
    gap = max(1, int(170 * scale))

    # Logical pixels per frame.
    pipe_speed = 4.2

    return pipe_width, gap, pipe_speed


def create_pipe_pair(scale, width, height, pipe_width, gap):
    subject = random.choice(SUBJECTS)

    minimum_center = int(170 * scale)
    maximum_center = height - int(170 * scale)

    if maximum_center <= minimum_center:
        center_y = height // 2
    else:
        center_y = random.randint(
            minimum_center,
            maximum_center
        )

    x = float(width + int(40 * scale))

    top_height = max(
        1,
        center_y - gap // 2
    )

    bottom_y = center_y + gap // 2

    bottom_height = max(
        1,
        height - bottom_y
    )

    top_rect = pygame.Rect(
        int(x),
        0,
        pipe_width,
        top_height
    )

    bottom_rect = pygame.Rect(
        int(x),
        bottom_y,
        pipe_width,
        bottom_height
    )

    return {
        "x": x,
        "top": top_rect,
        "bottom": bottom_rect,
        "subject": subject,
        "counted": False,
    }


def move_pipes(pipes_list, pipe_speed, scale, dt):
    movement = pipe_speed * scale * dt

    remaining = []

    for pipe in pipes_list:
        pipe["x"] -= movement

        x = int(pipe["x"])

        pipe["top"].x = x
        pipe["bottom"].x = x

        if pipe["top"].right > -5:
            remaining.append(pipe)

    return remaining


# ============================================================
# PIPE DRAWING
# ============================================================

def draw_pipes(pipes_list, label_font, scale):
    for pipe in pipes_list:
        color = PIPE_COLORS[pipe["subject"]]

        pygame.draw.rect(
            screen,
            color,
            pipe["top"]
        )

        pygame.draw.rect(
            screen,
            color,
            pipe["bottom"]
        )

        label = label_font.render(
            pipe["subject"],
            True,
            (20, 20, 20)
        )

        rotated_label = pygame.transform.rotate(
            label,
            90
        )

        label_x = (
            pipe["top"].centerx
            - rotated_label.get_width() // 2
        )

        top_y = (
            pipe["top"].bottom
            - min(
                int(120 * scale),
                pipe["top"].height // 2
            )
        )

        bottom_y = (
            pipe["bottom"].top
            + int(20 * scale)
        )

        screen.blit(
            rotated_label,
            (
                label_x,
                top_y - rotated_label.get_height() // 2
            )
        )

        screen.blit(
            rotated_label,
            (
                label_x,
                bottom_y
            )
        )


# ============================================================
# COLLISION CAUSE IMAGES
# ============================================================

cause_images = {}


def load_cause_images(scale):
    key = round(scale, 2)

    if key in cause_images:
        return cause_images[key]

    images = {}

    extensions = {
        ".png",
        ".jpg",
        ".jpeg",
        ".webp",
    }

    image_size = max(
        1,
        int(300 * scale)
    )

    names = [
        "physics",
        "mathematics",
        "chemistry",
        "boundary",
    ]

    for name in names:

        filenames = []

        if name == "boundary":
            path = Path("boundary.jpg")

            if path.is_file():
                filenames.append(path)

        else:
            try:
                candidates = []

                for path in Path(".").iterdir():

                    if not path.is_file():
                        continue

                    if path.suffix.lower() not in extensions:
                        continue

                    stem = path.stem

                    if stem.lower().startswith(name):
                        number = stem[len(name):]

                        if number.isdigit():
                            candidates.append(
                                (int(number), path)
                            )

                candidates.sort(
                    key=lambda item: item[0]
                )

                filenames = [
                    path
                    for _, path in candidates
                ]

            except OSError:
                filenames = []

        variants = []

        for filename in filenames:
            try:
                image = pygame.image.load(
                    str(filename)
                ).convert_alpha()

                image = pygame.transform.smoothscale(
                    image,
                    (
                        image_size,
                        image_size
                    )
                )

                variants.append(image)

            except (pygame.error, OSError):
                continue

        if not variants:
            size = max(
                1,
                int(180 * scale)
            )

            fallback = pygame.Surface(
                (size, size),
                pygame.SRCALPHA
            )

            pygame.draw.circle(
                fallback,
                (200, 50, 50),
                (
                    size // 2,
                    size // 2
                ),
                size // 2
            )

            variants.append(fallback)

        images[name] = variants

    cause_images[key] = images

    return images


# ============================================================
# COLLISION
# ============================================================

def check_collision(bird_rect, pipes_list, height):
    if bird_rect.top <= 0:
        return "boundary"

    if bird_rect.bottom >= height:
        return "boundary"

    for pipe in pipes_list:
        if (
            bird_rect.colliderect(pipe["top"])
            or bird_rect.colliderect(pipe["bottom"])
        ):
            return pipe["subject"].lower()

    return None


# ============================================================
# GAME STATE
# ============================================================

score = 0
best = 0

game_active = True
show_help = True

bird_surface = None
bird_rect = None

bird_vel = 0.0
rotation = 0.0

pipes = []

collision_cause = None
chosen_image = None


# ============================================================
# RESET GAME
# ============================================================

def reset_game():
    global pipes
    global bird_surface
    global bird_rect
    global bird_vel
    global rotation
    global score
    global game_active
    global show_help
    global collision_cause
    global chosen_image

    width, height, scale = get_dimensions()

    bird_surface, bird_rect = reset_bird(
        scale,
        height
    )

    pipes.clear()

    bird_vel = 0.0
    rotation = 0.0

    score = 0

    game_active = True
    show_help = True

    collision_cause = None
    chosen_image = None


# ============================================================
# FLAP / INPUT
# ============================================================

def flap():
    global bird_vel
    global rotation
    global show_help

    _, jump_strength = get_physics()

    if not game_active:
        reset_game()

    bird_vel = jump_strength
    rotation = 20
    show_help = False


# ============================================================
# MAIN LOOP
# ============================================================

async def main():
    global screen
    global pipes
    global bird_surface
    global bird_rect
    global bird_vel
    global rotation
    global score
    global best
    global game_active
    global show_help
    global collision_cause
    global chosen_image

    last_scale = None

    reset_game()

    running = True

    while running:

        width, height, scale = get_dimensions()

        rounded_scale = round(scale, 2)

        if last_scale != rounded_scale:
            title_font, ui_font, label_font = get_fonts(scale)
            last_scale = rounded_scale

        gravity, jump_strength = get_physics()

        pipe_width, gap, pipe_speed = get_pipe_params(scale)

        # Normalize around 60 FPS.
        dt = clock.tick(60) / (1000 / 60)

        # Prevent giant jumps after browser tab switching.
        dt = min(dt, 2.0)

        # ====================================================
        # EVENTS
        # ====================================================

        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                running = False
                continue

            if event.type == pygame.KEYDOWN:

                if event.key in (
                    pygame.K_SPACE,
                    pygame.K_UP
                ):
                    flap()

            elif event.type == pygame.MOUSEBUTTONDOWN:

                if event.button == 1:
                    flap()

            elif event.type == pygame.FINGERDOWN:
                flap()

            elif (
                event.type == SPAWNPIPE
                and game_active
            ):
                pipes.append(
                    create_pipe_pair(
                        scale,
                        width,
                        height,
                        pipe_width,
                        gap
                    )
                )

            elif event.type == pygame.VIDEORESIZE:

                new_width = max(
                    320,
                    event.w
                )

                new_height = max(
                    480,
                    event.h
                )

                screen = pygame.display.set_mode(
                    (
                        new_width,
                        new_height
                    ),
                    pygame.RESIZABLE
                )

                reset_game()

        # ====================================================
        # UPDATE
        # ====================================================

        if game_active:

            bird_vel += gravity * dt

            bird_rect.centery += int(
                bird_vel * dt
            )

            rotation = max(
                -60,
                rotation - 4 * dt
            )

            pipes = move_pipes(
                pipes,
                pipe_speed,
                scale,
                dt
            )

            # Score.
            for pipe in pipes:

                if (
                    not pipe["counted"]
                    and pipe["top"].right < bird_rect.left
                ):
                    pipe["counted"] = True
                    score += 1

            # Collision.
            cause = check_collision(
                bird_rect,
                pipes,
                height
            )

            if cause:

                collision_cause = cause

                images = load_cause_images(
                    scale
                )

                variants = images.get(
                    collision_cause,
                    []
                )

                if variants:
                    chosen_image = random.choice(
                        variants
                    )
                else:
                    chosen_image = None

                game_active = False

                best = max(
                    best,
                    score
                )

        # ====================================================
        # DRAW
        # ====================================================

        screen.fill(BG)

        # Grid.
        grid_step = max(
            1,
            int(35 * scale)
        )

        for x in range(
            0,
            width,
            grid_step
        ):
            pygame.draw.line(
                screen,
                GRID,
                (x, 0),
                (x, height)
            )

        for y in range(
            0,
            height,
            grid_step
        ):
            pygame.draw.line(
                screen,
                GRID,
                (0, y),
                (width, y)
            )

        # Pipes.
        draw_pipes(
            pipes,
            label_font,
            scale
        )

        # Bird.
        rotated = pygame.transform.rotate(
            bird_surface,
            rotation
        )

        rotated_rect = rotated.get_rect(
            center=bird_rect.center
        )

        screen.blit(
            rotated,
            rotated_rect
        )

        # ====================================================
        # UI
        # ====================================================

        title = title_font.render(
            "XII C",
            True,
            WHITE
        )

        screen.blit(
            title,
            (
                width // 2
                - title.get_width() // 2,
                int(24 * scale)
            )
        )

        score_text = ui_font.render(
            f"Subjects survived: {score}",
            True,
            WHITE
        )

        best_text = ui_font.render(
            f"Best: {best}",
            True,
            WHITE
        )

        screen.blit(
            score_text,
            (
                int(16 * scale),
                int(70 * scale)
            )
        )

        screen.blit(
            best_text,
            (
                width
                - best_text.get_width()
                - int(16 * scale),
                int(70 * scale)
            )
        )

        # ====================================================
        # HELP
        # ====================================================

        if show_help and game_active:

            help_msg = ui_font.render(
                "Press SPACE or Tap to flap",
                True,
                WHITE
            )

            screen.blit(
                help_msg,
                (
                    width // 2
                    - help_msg.get_width() // 2,
                    height // 2
                    - int(16 * scale)
                )
            )

        # ====================================================
        # GAME OVER
        # ====================================================

        if not game_active:

            if chosen_image:

                image_rect = chosen_image.get_rect(
                    center=(
                        width // 2,
                        height // 2
                    )
                )

                screen.blit(
                    chosen_image,
                    image_rect
                )

            blink = (
                pygame.time.get_ticks() // 500
            ) % 2

            if blink:

                over = title_font.render(
                    "Game Over",
                    True,
                    RED
                )

                screen.blit(
                    over,
                    (
                        width // 2
                        - over.get_width() // 2,
                        height // 2
                        - over.get_height() // 2
                    )
                )

            tip = ui_font.render(
                "Press SPACE or Tap to try again",
                True,
                WHITE
            )

            screen.blit(
                tip,
                (
                    width // 2
                    - tip.get_width() // 2,
                    height // 2
                    + int(120 * scale)
                )
            )

        # ====================================================
        # DISPLAY / PYGBAG YIELD
        # ====================================================

        pygame.display.flip()

        await asyncio.sleep(0)

    pygame.quit()


# ============================================================
# START
# ============================================================

if __name__ == "__main__":
    asyncio.run(main())